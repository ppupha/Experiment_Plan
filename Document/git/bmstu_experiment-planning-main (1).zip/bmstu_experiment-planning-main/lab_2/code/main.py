import sys
from widget import qt_app


if __name__ == '__main__':
    sys.exit(qt_app())
