class ParameterError(ValueError):
    pass