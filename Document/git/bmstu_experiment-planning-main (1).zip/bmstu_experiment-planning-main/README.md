# bmstu_experiment-planning
bmstu, IU7-8, Планирование Эксперимента (2021)
