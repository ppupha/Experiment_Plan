from full_plan_table_widget import *


class PartialPlanTableWidget(PlanTableWidget):
    def __init__(self):
        super().__init__('partial_plan_table.ui')
