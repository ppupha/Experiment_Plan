from plan_table_widget import *


class FullPlanTableWidget(PlanTableWidget):
    def __init__(self):
        super().__init__('full_plan_table.ui')
