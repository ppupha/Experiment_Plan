class ParameterError(ValueError):
    pass
