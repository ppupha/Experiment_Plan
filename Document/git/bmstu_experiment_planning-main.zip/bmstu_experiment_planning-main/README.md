# bmstu_experiment_planning
BMSTU experiment planning course work (2021)

Спасибо за 3 и 4 л/р [Дмитрию Иванову](https://gitlab.com/Rabter)
