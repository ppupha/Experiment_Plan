class ParameterError(ValueError):
    pass